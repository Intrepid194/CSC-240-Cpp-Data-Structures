Files
	
Graph These files contain functions, not complete programs
	QueType.h		Specification and implementation of QueType
				class template
	StackTType.h	Specification and implementation of StackType class
				template
	MaxItems.h	Set MAX_ITEMS
	GrahType.h	Specification and implementation of GraphType
				class template (implemented in text)
	DFSearch.cpp	Depth-first search
	BFSearch.cpp	Breadth-first search
	ShortestPath.cpp	Shortest path algorithm
