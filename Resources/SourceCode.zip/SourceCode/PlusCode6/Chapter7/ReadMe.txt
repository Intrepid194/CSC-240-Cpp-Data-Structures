Files

  Misc. code Files: Caution--none of these files contain complete programs.

	Factorial.cpp 	Recursive factorial function.
	Insert.cpp 	Recursive insertion into a linked list.
	Delete.cpp 	Recursive deletion from a linked list.
	BinSearch.cpp 	Recursive binary search algorithm.
	ComBin.cpp 	Combinatorial function (aka binomial coefficients).

	ValueIn.cpp 	Function ValueInList.

	ValueIn2.cpp 	Function ValueInList where the recursive call is not the 					last.

	RevPrint.cpp 	Recursive function to print a linked list in reverse order.

	RevPr2.cpp 	Function to print a linked list in reverse order using
				a stack.

  Maze
	MazeDr.cpp	Driver for class Maze
	Maze.h		Specification file for class Maze
	Maze.cpp		Implementation file for class Maze
	maze1		Data file for driver where no trap can occur
	maze2		Data file for driver where a trap can occur

  QuickSort.cpp		QuickSort algorithm
  QuickSort2.cpp		QuickSort with alternate splitting algorithm
