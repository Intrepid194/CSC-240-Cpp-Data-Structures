//
//  ItemType.hpp
//  MergeSort
//
//  Created by Charles Weems on 1/16/16.
//  Copyright © 2016 Charles Weems. All rights reserved.
//

#ifndef ItemType_hpp
#define ItemType_hpp
#endif /* ItemType_hpp */
