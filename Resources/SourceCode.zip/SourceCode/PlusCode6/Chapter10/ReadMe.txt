Files:

AVLTree.cc, AVLTree.h     AVL tree implementation
RBTree.cc, RBTree.cc      Red-Black tree implementation
